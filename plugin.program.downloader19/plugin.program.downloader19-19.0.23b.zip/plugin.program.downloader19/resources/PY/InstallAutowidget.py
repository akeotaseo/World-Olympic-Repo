﻿import os, xbmc, xbmcvfs, xbmcgui, shutil, glob


def installautowidget(): 
         xbmc.executebuiltin('InstallAddon(plugin.program.autowidget)')
         xbmc.sleep(1000)
         xbmc.executebuiltin('SendClick(11)')
         addon_path = xbmc.translatePath('special://home/addons')
         dir_list = glob.iglob(os.path.join(addon_path, "plugin.program.autowidget"))
         for path in dir_list:
             if os.path.exists(addon_path): xbmcgui.Dialog().notification("[B][COLOR orange]AutoWidget[/COLOR][/B]", "[COLOR white]Είναι ήδη εγκατεστημένο![/COLOR]"),
installautowidget()
