import os, xbmc, xbmcgui, glob, shutil

def fix():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]World[/COLOR][/B]', '[COLOR white] Για αλλαγή του skin απο "Εικονίδια" σε "Γραμματοσειρά", πατήστε[/COLOR]  [COLOR red]Skin[/COLOR] Text στο [COLOR lime]DialogButtonMenu[/COLOR] (Για να επαναφέρετε το skin στα Εικονίδια, πατήστε [COLOR red]Skin[/COLOR] Graph)',
                                        nolabel='[COLOR orange]Κλείσε[/COLOR]',yeslabel='[COLOR lime]DialogButtonMenu[/COLOR]')

        if choice == 1: xbmc.executebuiltin('activatewindow(shutdownmenu)'),

fix