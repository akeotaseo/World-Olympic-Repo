import xbmc, xbmcgui


def gamato():
    funcs = (click_1, click_2, click_3, click_4)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                   Gamato by Cartoons.gr [/COLOR][/B]', 
['[B][COLOR=white]                                                       Ταινίες[/COLOR][/B]',
 '[B][COLOR=white]                                                          Έτος[/COLOR][/B]',
 '[B][COLOR=white]                                                    Κατηγορίες[/COLOR][/B]',
 '[B][COLOR=white]                                                     Αναζήτηση[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=4&amp;url=http://gamatotv.info/movies/,return)')

def click_2():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/Gamato_year.py)')

def click_3():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.autowidget/folders/py/Gamato_genre.py)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.cartoonsgr/?description&amp;mode=18&amp;url=http://gamatotv.info/,return)')


gamato()
