import xbmc, xbmcgui


def OneClick():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ OneClick ~[/COLOR][/B]', 
['[B][COLOR=white][COLORyellow][B]New Movies Free[/COLOR][/COLOR][/B]',
 '[B][COLOR=white][COLORyellow][B]TV Shows[/COLOR][/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://mad-eric.bitbucket.io/newrels.xml",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.microjen/get_list/https://bitbucket.org/Mad-Eric/textfiles/raw/master/tvsel.json",return)')

OneClick()
