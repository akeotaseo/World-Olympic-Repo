import os, xbmc, xbmcgui

def install_stalker():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]TechNEWSology[/COLOR]', '[COLOR white]Περιμένετε να γίνει η εγκατάσταση και να φορτώσει τα κανάλια... Μετά την εγκατάσταση, αν δεν φορτώνει κανάλια δοκιμάστε να κάνετε ανανέωση καναλιών απο το [B]"Αλλαγή Πύλης"[/B][/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Εγκατάσταση[/COLOR]')

        if choice == 1: xbmc.executebuiltin('InstallAddon(pvr.stalker)')

install_stalker()
