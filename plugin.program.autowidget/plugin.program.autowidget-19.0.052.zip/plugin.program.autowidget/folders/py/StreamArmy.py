import os, xbmc, xbmcvfs, xbmcgui


def streamarmy():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Fix nemesisaio / EntertainMe[/COLOR]', 'Επιλέξτε [COLOR green]Remove Data[/COLOR][CR]Στην συνέχεια ανοίξτε τα πρόσθετα [COLOR orange]NemesisAio / EntertainMe[/COLOR] απο το SubMenu στις κατηγορίες MOVIES & TV - SPORTS',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Remove Data[/COLOR][/B]')

        if choice == 1: xbmc.executebuiltin('PlayMedia("plugin://plugin.program.G.K.N.Wizard/?mode=removedata&name=plugin.program.downloader")')


streamarmy()
