import xbmc, xbmcgui


def butterfingers():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]~ Butter Fingers ~[/COLOR][/B]', 
['[B][COLOR=white]Ani-Mate[/COLOR][/B]',
 '[B][COLOR=white]Butter Fingers Movies[/COLOR][/B]',
 '[B][COLOR=white]Channels[/COLOR][/B]',
 '[B][COLOR=white]Diy Fix[/COLOR][/B]',
 '[B][COLOR=white]Docula[/COLOR][/B]',
 '[B][COLOR=white]Kidz Club[/COLOR][/B]',
 '[B][COLOR=white]Muzic[/COLOR][/B]',
 '[B][COLOR=white]Risque[/COLOR][/B]',
 '[B][COLOR=white]Sportz[/COLOR][/B]',
 '[B][COLOR=white]Super Flix[/COLOR][/B]',
 '[B][COLOR=white]Wrestlers[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-11]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.animate/",return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.bfingers/",return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.channels/",return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.diyfix/",return)')
    
def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.docula/",return)')
    
def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.kidzclub/",return)')

def click_7():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.muzic/",return)')
    
def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.risque/",return)')
    
def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportz/",return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.superflix/",return)')
    
def click_11():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.wrestlers/",return)')


butterfingers()
