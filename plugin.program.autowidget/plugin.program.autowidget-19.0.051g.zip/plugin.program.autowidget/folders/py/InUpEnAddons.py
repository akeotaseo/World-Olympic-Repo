﻿import os, xbmc, xbmcvfs, xbmcgui, xbmcaddon, shutil, glob

def inupenaddons():        
        choice = xbmcgui.Dialog().yesno('[COLOR orange]Fix addons[/COLOR]', '[CR][B]Εγκατάσταση Ενεργοποίηση Ενημέρωση πρόσθετων.[/B][CR][CR]Για να συνεχίσετε πατήστε [B][COLOR green]Fix addons[/COLOR][/B] και περιμένετε...',
                                        nolabel='[B][COLOR white]Όχι τώρα...[/COLOR][/B]',yeslabel='[B][COLOR green]Fix addons[/COLOR][/B]')
                                        
        if choice == 1: [xbmc.executebuiltin('installAddon()'),
                         xbmc.sleep(1000),
                         xbmc.executebuiltin('addonsEnable.enable_addons()'),
                         xbmc.sleep(2000),
                         xbmc.executebuiltin('RunAddon()'),
                         xbmc.sleep(5000),
                         xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=forceupdate)'),
                         xbmc.sleep(6000),
                         xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=fixaddonupdate)'),]
                         
inupenaddons()
